export class Projekt {
    constructor(obj) {
        Object.assign(this, obj)
    }
}

